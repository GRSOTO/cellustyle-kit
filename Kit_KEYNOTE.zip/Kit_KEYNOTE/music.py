import sys;sys.path.insert(0,'/home/claude/k')
import numpy as np,soundfile as sf
from scipy.signal import butter,sosfilt
from tm import *
exec(open('/home/claude/k/ficha.py', encoding='utf-8').read().split('# ---------------- graphics')[0].split('RED = (255')[0])
SR=48000; L=DUR+0.6; N=int(L*SR); t=np.arange(N)/SR
rng=np.random.default_rng(3)
sec=[o(x) for x in SECCIONES]
BPM=96; beat=60/BPM
# offset so sections near beats
best=min(np.arange(0,beat,0.01),key=lambda off:sum(min(abs((s-off)/beat-round((s-off)/beat)),0.5) for s in sec))
off=best; print('offset',off)
def lp(x,f,o=2): return sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=2): return sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
def bp(x,a,b): return sosfilt(butter(2,[a,b],'band',fs=SR,output='sos'),x)
def add(buf,x,at):
    i=int(at*SR)
    if i<0: x=x[-i:]; i=0
    j=min(len(buf),i+len(x)); 
    if j>i: buf[i:j]+=x[:j-i]
mtr=lambda n:440*2**((n-69)/12)
# progression (midi): Am9, Fmaj7, Cmaj7, G6 ; 1 bar each = 4 beats
prog=[[50,53,57,60,64],[46,50,53,57,62],[43,46,50,53,57],[45,50,52,55,57]]
roots=[38,34,31,33]
music=np.zeros(N); drums=np.zeros(N)
bar=4*beat; nb=int((L-off)/bar)+2
for b in range(-1,nb):
    st=off+b*bar; ch=prog[b%4]
    # pad
    d=bar+0.3; tt=np.arange(int(d*SR))/SR
    env=np.minimum(1,tt/0.35)*np.minimum(1,(d-tt)/0.3)
    pad=sum(np.sin(2*np.pi*mtr(n)*tt+ k)*0.5+np.sin(2*np.pi*mtr(n)*1.003*tt)*0.5 for k,n in enumerate(ch))
    add(music,lp(pad*env,1800)*0.05,st)
    # keys pluck (rhodes-ish) on beat 1 and 2.5
    for bb in [0,1.5,2.5]:
        tt=np.arange(int(1.2*SR))/SR; e=np.exp(-tt*3.2)
        k=sum(np.sin(2*np.pi*mtr(n+12)*tt)*(1+0.3*np.sin(2*np.pi*5*tt)) for n in ch[1:4])
        add(music,k*e*0.035,st+bb*beat)
    # bass
    tt=np.arange(int(bar*SR))/SR; e=np.minimum(1,tt/0.02)*np.exp(-tt*0.8)
    add(music,np.sin(2*np.pi*mtr(roots[b%4])*tt)*e*0.16,st)
    # drums
    for bb in range(4):
        bt=st+bb*beat
        if bb in (0,2):
            tt=np.arange(int(0.35*SR))/SR; f=50+90*np.exp(-tt*30)
            add(drums,np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*9)*0.55,bt)
        if bb in (1,3):
            tt=np.arange(int(0.18*SR))/SR
            add(drums,bp(rng.normal(size=len(tt)),1200,5000)*np.exp(-tt*25)*0.12,bt)
        for h in (0,0.5):
            tt=np.arange(int(0.04*SR))/SR
            add(drums,hp(rng.normal(size=len(tt)),7000)*np.exp(-tt*90)*(0.05 if h else 0.035),bt+h*beat)
mix=music+drums
# impacts at sections + riser before
for s in [0.0]+sec:
    tt=np.arange(int(1.6*SR))/SR; f=40+60*np.exp(-tt*6)
    boom=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*2.5)*0.6
    add(mix,boom,s)
    if s>0:
        d=0.6; tt=np.arange(int(d*SR))/SR
        rise=hp(rng.normal(size=len(tt)),3000)*(tt/d)**2*0.08
        add(mix,rise,s-d)
# end: stop music at DUR with final hit
end=int(DUR*SR); fade=int(0.05*SR); mix[end:end+fade]*=np.linspace(1,0,fade); mix[end+fade:]=0
tt=np.arange(int(0.6*SR))/SR; add(mix,np.sin(2*np.pi*np.cumsum(45+60*np.exp(-tt*8))/SR)*np.exp(-tt*6)*0.5,DUR-0.05)
mix=mix[:int((DUR+0.5)*SR)]
mix/=np.max(np.abs(mix))*1.1
sf.write('/home/claude/k/music.wav',mix,SR)
# SFX track
sfx=np.zeros(len(mix))
def whoosh(at):
    d=0.45; tt=np.arange(int(d*SR))/SR; n=rng.normal(size=len(tt))
    env=np.sin(np.pi*tt/d)**2
    x=np.zeros_like(n); 
    for k in range(6):
        seg=slice(int(k*len(n)/6),int((k+1)*len(n)/6)); x[seg]=bp(n,300+k*500,900+k*900)[seg]
    add(sfx,x*env*0.25,at-d*0.6)
def tick(at):
    tt=np.arange(int(0.05*SR))/SR; add(sfx,np.sin(2*np.pi*2200*tt)*np.exp(-tt*120)*0.25,at)
def ding(at):
    tt=np.arange(int(1.2*SR))/SR; x=(np.sin(2*np.pi*1760*tt)+0.6*np.sin(2*np.pi*2637*tt)+0.3*np.sin(2*np.pi*3520*tt))*np.exp(-tt*4)
    add(sfx,x*0.12,at)
def pop(at):
    tt=np.arange(int(0.08*SR))/SR; f=300+600*np.exp(-tt*60); add(sfx,np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*50)*0.3,at)
for s in sec: whoosh(s)
for x in SFX.get('tick',[]): tick(o(x))
for x in SFX.get('ding',[]): ding(o(x))
for x in SFX.get('pop',[]): pop(o(x))
for x in SFX.get('buzz',[]):
    tt=np.arange(int(0.35*SR))/SR; add(sfx,np.sign(np.sin(2*np.pi*180*tt))*np.exp(-tt*9)*0.08,o(x))
sf.write('/home/claude/k/sfx.wav',sfx,SR)
print('ok',len(mix)/SR)
