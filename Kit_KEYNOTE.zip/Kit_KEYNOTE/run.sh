#!/bin/bash
# bash run.sh prep VIDEO.MOV   -> transcribe, calcula cortes, hoja de contactos (/home/claude/k/cs.jpg)
# bash run.sh test 1,5,10,20   -> tira de prueba (/home/claude/k/test.jpg), tiempos de SALIDA
# bash run.sh render NOMBRE    -> MP4 final en /home/claude/k/NOMBRE.mp4
set -e
H=$(cd "$(dirname "$0")" && pwd); K=/home/claude/k
mkdir -p $K /home/claude/v; cp "$H"/{tm.py,audio.py,music.py,render.py,transcribir.py} $K/
cd $K
if [ "$1" = prep ]; then
  cp "$2" /home/claude/v/in.mov
  pip install -q --break-system-packages faster-whisper soundfile noisereduce opencv-python-headless pillow scipy 2>/dev/null || true
  [ -f sh.rnnn ] || curl -sSL -o sh.rnnn https://raw.githubusercontent.com/GregorR/rnnoise-models/master/somnolent-hogwash-2018-09-01/sh.rnnn || true
  python3 transcribir.py
elif [ "$1" = test ]; then
  python3 render.py test "$2"
else
  python3 audio.py && python3 music.py && python3 render.py
  ffmpeg -v error -y -i v_cut.wav -af loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000 voz.wav
  ffmpeg -v error -y -i music.wav -af "highpass=f=60,equalizer=f=280:t=q:w=1:g=-4,loudnorm=I=-25,aresample=48000" mus.wav
  ffmpeg -v error -y -i voz.wav -i mus.wav -i sfx.wav -filter_complex "[0:a]asplit=2[v][sc];[1:a][sc]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=300[m];[v][m][2:a]amix=inputs=3:normalize=0:duration=first,loudnorm=I=-14:TP=-1:LRA=11,aresample=48000[a]" -map "[a]" mix.wav
  ffmpeg -v error -y -i video_noaudio.mp4 -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart "$K/${2:-video_editado}.mp4"
  echo "LISTO: $K/${2:-video_editado}.mp4"
fi
