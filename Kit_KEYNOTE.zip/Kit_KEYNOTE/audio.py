import numpy as np,soundfile as sf,subprocess,noisereduce as nr
from tm import *
SR=48000
subprocess.run(['ffmpeg','-v','error','-y','-i','/home/claude/v/in.mov','-af',('arnndn=m=sh.rnnn:mix=0.9' if __import__('os').path.exists(D+'sh.rnnn') else 'afftdn=nf=-25'),'-ac','1','-ar','48000',D+'rnn.wav'],check=True)
y,_=sf.read(D+'rnn.wav'); y=nr.reduce_noise(y=y,sr=SR,stationary=True,prop_decrease=0.5); sf.write(D+'v1.wav',y,SR)
subprocess.run(['ffmpeg','-v','error','-y','-i',D+'v1.wav','-af','highpass=f=90,equalizer=f=220:t=q:w=1:g=-3,equalizer=f=3000:t=q:w=1.2:g=3,equalizer=f=7200:t=q:w=2:g=-3,acompressor=threshold=-24dB:ratio=3.5:attack=6:release=110:makeup=4,alimiter=limit=0.9',D+'v2.wav'],check=True)
v,_=sf.read(D+'v2.wav'); fd=int(0.012*SR); parts=[]
for s,e in segs:
    p=v[int(round(s*SR)):int(round(e*SR))].copy(); p[:fd]*=np.linspace(0,1,fd); p[-fd:]*=np.linspace(1,0,fd); parts.append(p)
sf.write(D+'v_cut.wav',np.concatenate(parts),SR); print('voz',DUR)
