# Arma whisper small desde npm, transcribe con tiempos por palabra, calcula cortes (huecos >0,14 s) y hoja de contactos 1 fps.
import os,subprocess,json,wave,numpy as np
D='/home/claude/k/'; M='/home/claude/wmodel/'
if not os.path.exists(M+'model.bin'):
    os.makedirs(M+'p',exist_ok=True)
    for i in range(4): subprocess.run(f'cd {M}p && npm pack @skillninja/shortmovie-telop-model-p{i} --silent && tar xzf *p{i}-*.tgz && mv package p{i}',shell=True,check=True)
    subprocess.run(f'cp {M}p/p0/{{tokenizer.json,vocabulary.json,config.json,preprocessor_config.json}} {M} && cat {M}p/p0/model.bin.part0 {M}p/p1/model.bin.part1 {M}p/p2/model.bin.part2 {M}p/p3/model.bin.part3 > {M}model.bin',shell=True,check=True,executable='/bin/bash')
subprocess.run(['ffmpeg','-v','error','-y','-i','/home/claude/v/in.mov','-ac','1','-ar','16000',D+'a16.wav'],check=True)
w=wave.open(D+'a16.wav');a=np.frombuffer(w.readframes(w.getnframes()),np.int16).astype(np.float32)/32768
from faster_whisper import WhisperModel
s,_=WhisperModel(M,compute_type='int8').transcribe(a,language='es',word_timestamps=True)
W=[[x.start,x.end,x.word.strip()] for seg in s for x in seg.words]
json.dump(W,open(D+'words.json','w'),ensure_ascii=False)
def db(t0,t1):
    g=a[int(t0*16000):int(t1*16000)]; return 20*np.log10(np.sqrt((g**2).mean())+1e-9) if len(g) else -99
segs=[];cur=None
for st,en,t in W:
    s0=max(st-0.03,0);e0=en+0.08
    if cur and (s0-cur[1]<=0.14 or db(cur[1],s0)>-28): cur[1]=max(cur[1],e0)   # hueco con voz = no se corta
    else:
        if cur: segs.append(cur)
        cur=[s0,e0]
segs.append(cur)
for i in range(1,len(segs)):
    if segs[i][0]<segs[i-1][1]: segs[i-1][1]=segs[i][0]
segs=[[round(x,2),round(y,2)] for x,y in segs]
json.dump(segs,open(D+'segs.json','w'))
subprocess.run(['ffmpeg','-v','error','-y','-i','/home/claude/v/in.mov','-vf',"fps=1,scale=180:-1,drawtext=text='%{pts\\:flt}':x=5:y=5:fontsize=22:fontcolor=yellow,tile=9x5",'-frames:v','1',D+'cs.jpg'],check=True)
print('SEGS',segs,'DUR',round(sum(e-s for s,e in segs),2))
print(' '.join(f'{t}@{a_:.2f}' for a_,b,t in W))
