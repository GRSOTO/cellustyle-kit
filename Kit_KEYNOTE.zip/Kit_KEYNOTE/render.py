import sys, json, subprocess, math
sys.path.insert(0, '/home/claude/k')
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
from tm import segs, DUR, o

SRC = '/home/claude/v/in.mov'
W, H, FPS = 1080, 1920, 30
F = '/usr/share/fonts/opentype/inter/'
def font(name, size): return ImageFont.truetype(F + name, size)
LIME = (151, 255, 0)
WHITE = (255, 255, 255)
GRAY = (150, 150, 150)

def raw_to_out(t):
    acc = 0
    for s, e in segs:
        if t < s: return acc
        if t <= e: return acc + t - s
        acc += e - s
    return acc

def shot_for(traw):
    for s, e, k in shots:
        if s - 1e-6 <= traw < e + 1e-6: return s, e, k
    return shots[-1]

def ease_out(p): p = min(max(p, 0), 1); return 1 - (1 - p) ** 3
def back(p):
    p = min(max(p, 0), 1); c1 = 1.5; c3 = c1 + 1
    return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2

# ---------------- grade ----------------
x = np.arange(256) / 255.0
curve = np.clip(0.5 + (x - 0.5) * 1.06 + 0.02 * np.sin(2 * np.pi * x) * 0, 0, 1)
lut_r = np.clip(curve * 1.02 * 255, 0, 255).astype(np.uint8)
lut_g = np.clip(curve * 1.00 * 255, 0, 255).astype(np.uint8)
lut_b = np.clip(curve * 0.97 * 255, 0, 255).astype(np.uint8)
yy, xx = np.mgrid[0:H, 0:W]
d = np.sqrt(((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2)
vig = (1 - 0.18 * np.clip(d - 0.55, 0, 1) ** 1.5)[..., None].astype(np.float32)
rng = np.random.default_rng(1)
grains = [rng.normal(0, 3.2, (H, W, 1)).astype(np.float32) for _ in range(6)]

def grade(img, k):
    img = np.dstack([cv2.LUT(img[..., 0], lut_r), cv2.LUT(img[..., 1], lut_g), cv2.LUT(img[..., 2], lut_b)]).astype(np.float32)
    g = img.mean(axis=2, keepdims=True)
    img = g + (img - g) * 1.07
    img = img * vig + grains[k % 6]
    return np.clip(img, 0, 255).astype(np.uint8)

# ---------------- framing ----------------
def frame_view(src, traw, tout):
    s, e, (kind, c, z) = shot_for(traw)
    p = (traw - s) / max(e - s, 1e-3)
    zz = z * (1 + 0.035 * ease_out(p))
    for st in SECTIONS:
        dt = tout - st
        if 0 <= dt < 0.3: zz *= 1 + 0.07 * (1 - dt / 0.3) ** 2
    if tout < 0.35: zz *= 1 + 0.08 * (1 - tout / 0.35) ** 2
    cw, ch = W / zz, H / zz
    cx = min(max(c[0], cw / 2), W - cw / 2); cy = min(max(c[1], ch / 2), H - ch / 2)
    M = np.float32([[zz, 0, -(cx - cw / 2) * zz], [0, zz, -(cy - ch / 2) * zz]])
    return cv2.warpAffine(src, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

# ---------------- graphics ----------------
fLabel = font('Inter-SemiBold.otf', 38)
fHead = font('Inter-ExtraBold.otf', 44)
fBig = font('Inter-Black.otf', 150)
fTitle = font('Inter-Black.otf', 124)
fMid = font('Inter-Black.otf', 88)
fRow = font('Inter-Black.otf', 74)
fCap = font('Inter-SemiBold.otf', 34)
fSub = font('Inter-SemiBold.otf', 44)

def spaced(draw, xy, text, fnt, fill, sp=5, anchor_center=False):
    widths = [draw.textlength(ch, font=fnt) for ch in text]
    total = sum(widths) + sp * (len(text) - 1)
    x0, y0 = xy
    if anchor_center: x0 -= total / 2
    for ch, wdt in zip(text, widths):
        draw.text((x0, y0), ch, font=fnt, fill=fill); x0 += wdt + sp
    return total

def alpha_in_out(t, t0, t1, din=0.28, dout=0.16):
    if t < t0 or t > t1: return 0, 0
    a = min(1, (t - t0) / (din * 0.7)) if din else 1
    a = min(a, (t1 - t) / dout) if dout else a
    dy = (1 - back((t - t0) / din)) * 34
    if t1 - t < dout: dy = -(1 - (t1 - t) / dout) * 14
    return max(0, min(1, a)), dy

exec(open('/home/claude/k/ficha.py', encoding='utf-8').read())

def plate_alpha(t, t0, t1):
    if t < t0 or t > t1: return 0, 1
    a = min(1, (t - t0) / 0.22, (t1 - t) / 0.16)
    sc = 0.96 + 0.04 * ease_out((t - t0) / 0.3)
    return max(0, a), sc

def composite(img, t):
    for t0, t1, (x0, y0, x1, y1) in PLATES:
        a, sc = plate_alpha(t, t0, t1)
        if a <= 0: continue
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        w2, h2 = (x1 - x0) * sc / 2, (y1 - y0) * sc / 2
        X0, Y0, X1, Y1 = int(cx - w2), int(cy - h2), int(cx + w2), int(cy + h2)
        roi = img[Y0:Y1, X0:X1].astype(np.float32)
        bl = cv2.GaussianBlur(roi, (0, 0), 22) * 0.38 + 6
        m = np.zeros((Y1 - Y0, X1 - X0), np.uint8)
        cv2.rectangle(m, (0, 0), (X1 - X0 - 1, Y1 - Y0 - 1), 255, -1)
        r = 30
        m[:] = 0
        cv2.rectangle(m, (r, 0), (X1 - X0 - r, Y1 - Y0), 255, -1); cv2.rectangle(m, (0, r), (X1 - X0, Y1 - Y0 - r), 255, -1)
        for (ccx, ccy) in [(r, r), (X1 - X0 - r, r), (r, Y1 - Y0 - r), (X1 - X0 - r, Y1 - Y0 - r)]:
            cv2.circle(m, (ccx, ccy), r, 255, -1, lineType=cv2.LINE_AA)
        mm = (cv2.GaussianBlur(m, (0, 0), 1.2).astype(np.float32) / 255 * a)[..., None]
        img[Y0:Y1, X0:X1] = (roi * (1 - mm) + bl * mm).astype(np.uint8)
    lay = np.asarray(draw_text_layer(t)).astype(np.float32)
    al = lay[..., 3:4] / 255
    top = img[:480].astype(np.float32)
    img[:480] = (top * (1 - al) + lay[..., :3] * al).astype(np.uint8)
    # flash on sections
    for st in SECTIONS:
        dt = t - st
        if 0 <= dt < 2 / FPS:
            img[:] = (img.astype(np.float32) * 0.7 + 255 * 0.3).astype(np.uint8)
    return img

def frames_needed():
    out = []
    for s, e in segs:
        a = int(round(s * FPS)); b = int(round(e * FPS))
        out += list(range(a, b))
    return out

def main(test_times=None):
    need = frames_needed()
    need_set = {f: i for i, f in enumerate(need)}
    targets = None
    if test_times:
        targets = set(int(round(tt * FPS)) for tt in test_times)
    dec = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', SRC, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-r', '30', '-'], stdout=subprocess.PIPE)
    enc = None; shots_out = []
    if not test_times:
        enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', '30', '-i', '-',
                                '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '/home/claude/k/video_noaudio.mp4'], stdin=subprocess.PIPE)
    fi = 0; fsz = W * H * 3
    while True:
        buf = dec.stdout.read(fsz)
        if len(buf) < fsz: break
        if fi in need_set:
            oi = need_set[fi]
            if targets is None or oi in targets:
                src = np.frombuffer(buf, np.uint8).reshape(H, W, 3)
                traw = fi / FPS; tout = oi / FPS
                img = frame_view(src, traw, tout)
                img = grade(img, oi)
                img = composite(img, tout)
                if enc: enc.stdin.write(img.tobytes())
                else: shots_out.append((tout, img))
        fi += 1
    dec.stdout.close(); dec.wait()
    if enc: enc.stdin.close(); enc.wait()
    return shots_out

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'test':
        tt = [float(x) for x in sys.argv[2].split(',')]
        res = main(tt)
        thumbs = [cv2.resize(im, (270, 480)) for _, im in res]
        while len(thumbs) % 6: thumbs.append(np.zeros_like(thumbs[0]))
        rows = [np.hstack(thumbs[i:i + 6]) for i in range(0, len(thumbs), 6)]
        Image.fromarray(np.vstack(rows)).save('/home/claude/k/test.jpg', quality=88)
        print('frames', len(res))
    else:
        main(); print('done')
