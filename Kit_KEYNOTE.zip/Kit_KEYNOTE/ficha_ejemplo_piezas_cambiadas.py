# FICHA = lo único que se escribe por video (planos, secciones, efectos, textos). Ejemplo: IMG_6604 piezas cambiadas.
# Planos: A=normal, B=acercamiento a la cara 1,13-1,18, D=primer plano del celular 1,45-1,8. Nunca dos iguales seguidos.
# ---------------- shots (raw time) ----------------
A = ('A', (540, 960), 1.0)
B = ('B', (620, 900), 1.14)
PH = ('D', (300, 1250), 1.45)
shots = [
    (0.41, 2.05, ('B', (620, 900), 1.17)), (2.05, 4.06, A),
    (4.79, 6.80, A), (6.80, 9.40, PH), (9.40, 10.76, B),
    (11.69, 13.30, A), (13.30, 15.08, B),
    (15.25, 16.65, A), (16.65, 17.88, ('B', (620, 900), 1.18)),
    (18.47, 20.50, A), (20.50, 22.05, B), (22.05, 24.30, A), (24.30, 25.60, B), (25.60, 27.00, A),
    (27.83, 29.30, B), (29.30, 31.05, A), (31.05, 32.58, ('B', (620, 900), 1.18)),
]
SECCIONES = [4.79, 11.69, 15.25, 18.47, 24.36, 27.83, 31.10]   # tiempo crudo
SECTIONS = [o(x) for x in SECCIONES]

# ---------------- SFX (tiempo crudo) ----------------
SFX = {'tick': [4.82, 5.48, 5.72, 20.54, 21.04, 25.14], 'ding': [12.50, 25.66, 29.38], 'pop': [31.10, 7.92], 'buzz': [15.86]}

RED = (255, 77, 77)
def r(x): return o(x)
PLATES = [
    (r(0.41), r(4.06), (60, 100, 1020, 446)),
    (r(4.79), r(17.88), (250, 66, 830, 150)),
    (r(4.79), r(6.80), (50, 176, 1030, 446)),
    (r(6.84), r(10.76), (50, 176, 1030, 446)),
    (r(11.69), r(15.08), (50, 176, 1030, 446)),
    (r(15.25), r(17.88), (50, 176, 1030, 446)),
    (r(18.47), r(22.05), (50, 88, 1030, 400)),
    (r(22.10), r(24.30), (50, 88, 1030, 400)),
    (r(24.36), r(27.0), (50, 88, 1030, 446)),
    (r(27.83), r(31.05), (50, 88, 1030, 400)),
    (r(31.10), DUR + 1, (70, 100, 1010, 360)),
]
def check(dr, cx, cy, s, c, w=12):
    dr.line((cx - s, cy, cx - s * 0.3, cy + s * 0.7, cx + s, cy - s * 0.8), fill=c, width=w, joint='curve')
def cross(dr, cx, cy, s, c, w=12):
    dr.line((cx - s, cy - s, cx + s, cy + s), fill=c, width=w); dr.line((cx - s, cy + s, cx + s, cy - s), fill=c, width=w)

def draw_text_layer(t):
    lay = Image.new('RGBA', (W, 480), (0, 0, 0, 0))
    dr = ImageDraw.Draw(lay)
    def T_(t0, t1, fn, din=0.28, dout=0.16):
        a, dy = alpha_in_out(t, r(t0) if t0 < 40 else t0, r(t1) if t1 < 40 else t1, din, dout)
        if a > 0: fn(a, dy)
    def col(c, a): return c + (int(255 * a),)
    def big(txt, y, c, sz=124): return lambda a, dy: dr.text((W / 2, y + dy), txt, font=font('Inter-Black.otf', sz), fill=col(c, a), anchor='mm')
    def lab(txt, y, c=LIME): return lambda a, dy: spaced(dr, (W / 2, y + dy), txt, fLabel, col(c, a), 6, True)
    if t >= r(4.06):
        p = min(1, (t - r(4.06)) / (DUR - r(4.06)))
        dr.rectangle((0, 0, int(W * p), 7), fill=LIME + (255,))
    # HOOK
    T_(0.41, 2.80, lab('ANTES DE COMPRAR UN iPHONE', 140))
    T_(2.86, 4.06, lab('LO SABES EN 10 SEGUNDOS', 140, WHITE))
    T_(1.15, 4.06, big('¿PIEZAS', 262, WHITE))
    T_(1.50, 4.06, big('CAMBIADAS?', 380, LIME, 118))
    # header
    T_(4.79, 17.88, lambda a, dy: dr.text((W / 2, 108 + dy), 'HISTORIAL DE PIEZAS', font=fHead, fill=col(WHITE, a), anchor='mm'))
    # RUTA
    T_(4.79, 6.80, lab('LA RUTA', 210))
    T_(4.82, 6.80, lambda a, dy: dr.text((W / 2 - 200, 300 + dy), 'AJUSTES', font=font('Inter-Black.otf', 76), fill=col(WHITE, a), anchor='mm'))
    T_(5.48, 6.80, lambda a, dy: (dr.text((W / 2 + 10, 300 + dy), '›', font=font('Inter-Black.otf', 76), fill=col(LIME, a), anchor='mm'),
                                   dr.text((W / 2 + 220, 300 + dy), 'GENERAL', font=font('Inter-Black.otf', 76), fill=col(WHITE, a), anchor='mm')))
    T_(5.72, 6.80, lambda a, dy: dr.text((W / 2, 395 + dy), '› INFORMACIÓN', font=font('Inter-Black.otf', 80), fill=col(LIME, a), anchor='mm'))
    T_(6.84, 10.76, lab('BAJA HASTA EL FINAL', 210))
    T_(7.92, 10.76, big('HISTORIAL DE', 300, WHITE, 84))
    T_(8.44, 10.76, big('PIEZAS Y SERVICIO', 395, LIME, 76))
    # ORIGINAL
    T_(11.69, 15.08, lab('SI DICE', 210))
    def orig(a, dy):
        check(dr, 170, 305 + dy, 34, col(LIME, a), 14)
        dr.text((W / 2 + 40, 305 + dy), 'ORIGINAL', font=font('Inter-Black.otf', 120), fill=col(LIME, a), anchor='mm')
    T_(12.50, 15.08, orig)
    T_(12.96, 13.70, lambda a, dy: spaced(dr, (W / 2, 405 + dy), 'DE APPLE', fHead, col(WHITE, a), 6, True))
    T_(13.32, 15.08, lambda a, dy: dr.text((W / 2, 405 + dy), 'Tranquilo: la pieza es original', font=fSub, fill=col(WHITE, a), anchor='mm'))
    # DESCONOCIDA
    T_(15.25, 17.88, lab('SI DICE', 210, RED))
    def desc(a, dy):
        cross(dr, 110, 305 + dy, 30, col(RED, a), 14)
        dr.text((W / 2 + 40, 305 + dy), 'DESCONOCIDA', font=font('Inter-Black.otf', 104), fill=col(RED, a), anchor='mm')
    T_(15.86, 17.88, desc)
    T_(17.06, 17.88, lambda a, dy: spaced(dr, (W / 2, 405 + dy), 'NO ES ORIGINAL', fHead, col(WHITE, a), 6, True), din=0.18)
    # OJO
    T_(18.50, 22.05, lab('OJO', 130))
    T_(19.08, 22.05, big('NO SALE EN TODOS', 230, WHITE, 76))
    T_(20.88, 22.05, lambda a, dy: dr.text((W / 2, 330 + dy), 'SOLO MODELOS RECIENTES', font=font('Inter-Black.otf', 64), fill=col(LIME, a), anchor='mm'))
    T_(22.10, 24.30, lab('¿EL TUYO ES VIEJITO?', 130))
    T_(23.24, 24.30, big('NO TE SALE', 230, WHITE, 96))
    T_(23.66, 24.30, big('NO TE ASUSTES', 335, LIME, 84), din=0.2)
    # PAGAR
    T_(24.36, 27.0, lab('SI VAS A COMPRAR', 130))
    T_(25.14, 27.0, big('REVÍSALO', 240, WHITE, 110))
    T_(25.66, 27.0, big('ANTES DE PAGAR', 350, LIME, 96))
    def nodes(a, dy):
        x0 = W / 2; y0 = 425 + dy; f = fSub
        wdt = dr.textlength('no después', font=f)
        dr.text((x0, y0), 'no después', font=f, fill=col(GRAY, a), anchor='mm')
        p = ease_out((t - r(26.70)) / 0.3)
        dr.line((x0 - wdt / 2 - 6, y0 + 2, x0 - wdt / 2 - 6 + (wdt + 12) * p, y0 + 2), fill=col(RED, a), width=5)
    T_(26.58, 27.0, nodes, din=0.12)
    # NADA
    T_(27.86, 31.05, lab('SI NO APARECE NADA', 130))
    def nada(a, dy):
        check(dr, 190, 245 + dy, 30, col(LIME, a), 13)
        dr.text((W / 2 + 40, 245 + dy), 'TODO BIEN', font=font('Inter-Black.otf', 110), fill=col(LIME, a), anchor='mm')
    T_(29.14, 31.05, nada)
    T_(29.90, 31.05, lambda a, dy: dr.text((W / 2, 350 + dy), 'No le han cambiado piezas', font=fSub, fill=col(WHITE, a), anchor='mm'))
    # CTA
    T_(31.10, 99, lambda a, dy: dr.text((W / 2, 195 + dy), 'GUÁRDALO', font=fBig, fill=col(WHITE, a), anchor='mm'))
    def cta2(a, dy):
        bob = 6 * math.sin((t - r(31.10)) * 2 * math.pi * 1.6)
        dr.text((W / 2 - 25, 305 + dy), 'para cuando vayas a comprar', font=fSub, fill=col(LIME, a), anchor='mm')
        x0, y0 = W / 2 + 330, 305 + dy + bob
        dr.line((x0 - 16, y0 - 8, x0, y0 + 8, x0 + 16, y0 - 8), fill=col(LIME, a), width=7, joint='curve')
    T_(31.42, 99, cta2)
    return lay

