import json
D='/home/claude/k/'
segs=json.load(open(D+'segs.json'))
DUR=sum(e-s for s,e in segs)
def o(t):
    acc=0
    for s,e in segs:
        if t<s: return acc
        if t<=e: return acc+t-s
        acc+=e-s
    return acc
